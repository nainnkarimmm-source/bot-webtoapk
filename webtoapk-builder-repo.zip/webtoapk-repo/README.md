# WebToApk Builder — Repo "Kilang" APK

Repo ni fungsi sebagai "kilang" yang compile APK bila bot Telegram awak
minta (via GitHub Actions), supaya VPS bot awak sendiri tak perlu install
Android SDK.

## Setup (buat SEKALI sahaja)

1. **Buat repo GitHub baharu** (public — repo public dapat Actions minit
   PERCUMA tanpa had. Kalau private, ada had minit percuma bulanan).
2. Upload **SEMUA fail** dalam folder ni (kekalkan struktur folder sama
   persis — `.github/workflows/build-apk.yml` dan `android-template/`).
3. Buat **Personal Access Token (PAT)**:
   - Pergi https://github.com/settings/tokens → "Generate new token
     (classic)" atau "Fine-grained token".
   - Bagi izin: **Actions: Read and write**, **Contents: Read and write**.
   - Salin token tu (mula dengan `ghp_...` atau `github_pat_...`).
4. Masukkan dalam `config.js` bot awak:
   - `webtoapk.githubToken` = token tadi
   - `webtoapk.githubOwner` = username GitHub awak
   - `webtoapk.githubRepo` = nama repo yang awak buat tadi

## Macam mana ia jalan

1. Customer bot hantar link (atau kod HTML) + nama app.
2. Bot bayar/potong saldo, lepas tu trigger workflow ni via GitHub API
   (`workflow_dispatch`).
3. GitHub Actions compile APK (~2-5 minit, guna server GitHub, percuma).
4. Bot download APK yang siap dari "artifact" run tu, terus hantar kat
   customer dalam Telegram.

## Nota

- APK yang dihasilkan **debug build** (bukan untuk Google Play — cukup
  untuk install terus di telefon Android, "Install from Unknown Source").
- Setiap APK cuma disimpan 1 hari dalam GitHub (artifact retention),
  tapi bot dah download & hantar terus, jadi tak masalah.
- Kalau nak app_name/ikon lebih detail (ikon custom, splash screen),
  boleh extend `android-template/` ni — struktur dia projek Android
  Gradle biasa.
